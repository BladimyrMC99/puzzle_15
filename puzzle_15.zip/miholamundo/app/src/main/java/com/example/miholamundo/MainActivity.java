package com.example.miholamundo;

import androidx.appcompat.app.AppCompatActivity;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {

    Button siguiente;
    EditText Enviar;

    Button ayuda;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnMostrarDialog = findViewById(R.id.siguiente);
        Enviar = findViewById(R.id.nombre);
        siguiente = findViewById(R.id.siguiente);
        ayuda = findViewById(R.id.boton_ayuda);

        ayuda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent z = new Intent(MainActivity.this, ayuda.class);

                startActivity(z);
            }
        });


        siguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Bundle enviaDatos = new Bundle();
                enviaDatos.putString("keyDatos", Enviar.getText().toString());


                if (TextUtils.isEmpty(Enviar.getText().toString())) {
                    // Mostrar mensaje de advertencia
                    mostrarAlertDialog();
                } else {

                    Intent i = new Intent(MainActivity.this, activityDos.class);
                    i.putExtras(enviaDatos);
                    startActivity(i);

                }
            }
        });


    }
    private void mostrarAlertDialog () {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setMessage("Ingresa tu nombre para continuar")
                .setTitle("Advertencia ")
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Código a ejecutar al hacer clic en Aceptar
                        dialog.dismiss(); // Cierra el AlertDialog si es necesario
                    }
                });

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
