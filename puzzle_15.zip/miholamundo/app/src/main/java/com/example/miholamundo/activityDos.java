package com.example.miholamundo;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.Random;

public class activityDos extends AppCompatActivity {






    private int ladoX=3;
    private int ladoY=3;
    private RelativeLayout grupo;
    private Button[][] botones;

    private int[] tiles;

    private int movimientos = 0;

    private TextView movimientosText;
private TextView imprimeNombre;
 private String nom;

 private Button reinicio;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dos);



        imprimeNombre = findViewById(R.id.imprime_nombre);
Bundle recibeDatos= getIntent().getExtras();
String info= recibeDatos.getString("keyDatos");
imprimeNombre.setText(info);
        nom= recibeDatos.getString("keyDatos");
        msj_bienvenida();
loadViews();
loadNumbers();
generateNumbers();
loadDataToViews();
        checkWinInv();

    }


    private void loadDataToViews() {
        ladoX = 3;
        ladoY = 3;
        for (int i = 0; i < grupo.getChildCount(); i++) {
            botones[i / 4][i % 4].setText(String.valueOf(tiles[i]));
            botones[i / 4][i % 4].setBackgroundResource(android.R.drawable.btn_default);
        }
        botones[ladoX][ladoY].setText("");
        botones[ladoX][ladoY].setBackgroundColor(ContextCompat.getColor(this, R.color.colorfreebutton));
    }

    private  void generateNumbers(){

        int n=15;
        Random random = new Random();
        while (n>1) {
            int randomNum = random.nextInt(n--);
            int temp = tiles[randomNum];
            tiles[randomNum]=tiles[n];
            tiles[n]= temp;

        }
        if (!isSolvable())
            generateNumbers();
    }
    private boolean isSolvable(){
        int countInversion=0;
        for (int i = 0; i<15; i++){
            for (int j = 0; j<i; j++){
                if(tiles[j]>tiles[i])
                    countInversion++;
            }
        }
        return countInversion%2 == 0;
    }
    private void loadNumbers(){
        tiles = new int[16];
        for (int i = 0; i < grupo.getChildCount() - 1; i++){
            tiles[i] = i + 1;
        }
    }

    private void loadViews(){
        grupo = findViewById(R.id.group);
        botones = new Button[4][4];
        movimientosText = findViewById(R.id.text_view_steps);
        reinicio = findViewById(R.id.boton_reiniciar);
        for (int i = 0; i < grupo.getChildCount(); i++){
            botones[i / 4][i % 4] = (Button) grupo.getChildAt(i);
            botones[i / 4][i % 4].setClickable(true); // Asegúrate de que los botones sean clicables
        }
        reinicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                generateNumbers();
                loadDataToViews();
                loadViews();

                movimientosText.setText("movimientos = 0");
                movimientos=0;
            }
        });
    }

    public void buttonClick(View view) {
        Button button = (Button) view;
        int x = button.getTag().toString().charAt(0) - '0';
        int y = button.getTag().toString().charAt(1) - '0';

        if ((Math.abs(ladoX - x) == 1 && ladoY == y) || (Math.abs(ladoY - y) == 1 && ladoX == x)) {
            botones[ladoX][ladoY].setText(button.getText().toString());
            botones[ladoX][ladoY].setBackgroundResource(android.R.drawable.btn_default);
            button.setText("");
            button.setBackgroundColor(ContextCompat.getColor(this, R.color.colorfreebutton));
            ladoX = x;
            ladoY = y;
            movimientos++; // contador_movimientos
            movimientosText.setText("MOVIMIENTOS : "+movimientos);
            checkWin();
            checkWinLateral();
           checkWinEspiral();
            checkWinInv();

        }
    }

    public void checkWin() {
        boolean isWin = false;

        if (ladoX == 3 && ladoY == 3) {
            for (int i = 0; i < grupo.getChildCount() - 1; i++) {
                if (botones[i / 4][i % 4].getText().toString().equals(String.valueOf(i + 1))) {
                    isWin = true;
                } else {
                    isWin = false;
                    break;
                }
            }
        }
        if (isWin) {
            msj_victoriaN();
            for (int i = 0; i < grupo.getChildCount(); i++) {
                botones[i / 4][i % 4].setClickable(false);
            }

        }
    }


    public void checkWinInv() {
        boolean isWin = true;

        for (int i = 0; i < grupo.getChildCount(); i++) {
            int expectedValue = 16 - i;
            int currentRow = i / 4;
            int currentCol = i % 4;

            if (currentRow == ladoX && currentCol == ladoY) {
                // La posición actual está vacía, comprueba si el valor esperado es 16
                if (expectedValue != 1) {
                    isWin = false;
                    break;
                }
            } else {

                if (!botones[currentRow][currentCol].getText().toString().equals(String.valueOf(expectedValue))) {
                    isWin = false;
                    break;
                }
            }
        }

        if (isWin) {
            Toast.makeText(this, "FELICIDADES"+ nom +"Has ganado en modo IMPOSIBLE en " + movimientos + " movimientos!!!", Toast.LENGTH_SHORT).show();
            for (int i = 0; i < grupo.getChildCount(); i++) {
                botones[i / 4][i % 4].setClickable(false);
            }
        }
    }
    private static final int[][] POSICION_GANADORA = {
            {1, 5, 9, 13},
            {2, 6, 10, 14},
            {3, 7, 11, 15},
            {4, 8, 12, 0}
    };
    public void checkWinLateral() {
        boolean isWin = false;

        if (ladoX == 3 && ladoY == 3) {
            for (int i = 0; i < grupo.getChildCount() - 1; i++) {
                int fila = i / 4;
                int columna = i % 4;

                Log.d("DEBUG", "Valor actual: " + botones[fila][columna].getText().toString());
                Log.d("DEBUG", "Valor esperado: " + POSICION_GANADORA[fila][columna]);

                if (Integer.parseInt(botones[fila][columna].getText().toString()) == POSICION_GANADORA[fila][columna]) {
                    isWin = true;
                } else {
                    isWin = false;
                    break;
                }
            }
        }

        if (isWin) {

           msj_victoriaV();
            for (int i = 0; i < grupo.getChildCount(); i++) {
                botones[i / 4][i % 4].setClickable(false);
            }

        }
    }
   private static final int[][] POSICION_GANADORA_ESPIRAL = {
            {7, 8, 9, 10},
            {6, 1, 2, 11},
            {5, 4, 3, 12},
            {15, 14, 13, 0}
    };

    public void checkWinEspiral() {
        boolean isWin = false;

        if (ladoX == 3 && ladoY == 3) {
            for (int i = 0; i < grupo.getChildCount() - 1; i++) {
                int fila = i / 4;
                int columna = i % 4;

                Log.d("DEBUG", "Valor actual: " + botones[fila][columna].getText().toString());
                Log.d("DEBUG", "Valor esperado: " + POSICION_GANADORA_ESPIRAL[fila][columna]);

                if (Integer.parseInt(botones[fila][columna].getText().toString()) == POSICION_GANADORA_ESPIRAL[fila][columna]) {
                    isWin = true;
                } else {
                    isWin = false;
                    break;
                }
            }
        }

        if (isWin) {
           msj_victoriaE();
            for (int i = 0; i < grupo.getChildCount(); i++) {
                botones[i / 4][i % 4].setClickable(false);
            }

        }
    }

    private void msj_bienvenida() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setMessage("Bienvenido a este puzzle " +nom+ " buena suerte!!")
                .setTitle("Bienvenido ")
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Código a ejecutar al hacer clic en Aceptar
                        dialog.dismiss(); // Cierra el AlertDialog si es necesario
                    }
                });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void msj_victoriaN() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setMessage("Has ganado en modo Periferico " +nom+ " con "+ movimientos + " movimientos!!!")
                .setTitle("FELICIDADES ")
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Código a ejecutar al hacer clic en Aceptar
                        dialog.dismiss(); // Cierra el AlertDialog si es necesario
                    }
                });

        AlertDialog dialog = builder.create();
        dialog.show();
    }
    private void msj_victoriaV() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setMessage("Has ganado en modo VERTICAL " +nom+ " con "+ movimientos + " movimientos!!!")
                .setTitle("NADA MAL :0 ")
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Código a ejecutar al hacer clic en Aceptar
                        dialog.dismiss(); // Cierra el AlertDialog si es necesario
                    }
                });

        AlertDialog dialog = builder.create();
        dialog.show();
    }


    private void msj_victoriaE() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setMessage("Has ganado en modo ESPIRAL " +nom+ " con "+ movimientos + " movimientos!!!")
                .setTitle("FASCINANTE")
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Código a ejecutar al hacer clic en Aceptar
                        dialog.dismiss(); // Cierra el AlertDialog si es necesario
                    }
                });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

}